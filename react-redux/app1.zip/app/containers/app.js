import React, {Component} from 'react';
import { createStore, applyMiddleware, combineReducers } from 'redux';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';


import * as reducers from '../reducers';
import CounterApp from './counterApp';

const createStoreWithMiddleware = applyMiddleware(thunk)(createStore);
const reducer = combineReducers(reducers);
const store = createStoreWithMiddleware(reducer);

export default class App extends Component {
  render() {

    //es6代码测试
    state = {a:1, b:2, c:3}
    s = {...state, b:4}
    console.log('state statements:', s)

    //展开语法
    console.log({...state})

    //上面代码利用js 这种特性实现
    b = {a:1, a:2}
    console.log(b)

    return (
      <Provider store={store}>
        <CounterApp />
      </Provider>
    );
  }
}